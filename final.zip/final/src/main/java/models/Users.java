package models;

import org.json.JSONException;
import org.json.JSONObject;
import org.bson.Document;

public class Users {
	
	public static JSONObject getconv(Document doc) {
		JSONObject conv = new JSONObject();
		try {
		if(doc.containsKey("LinkedinID"))
			conv.put("LinkedinID",doc.getString("LinkedinID"));
		if(doc.containsKey("Rollno"))
			conv.put("Rollno",doc.getString("Rollno"));
		if(doc.containsKey("Password"))
			conv.put("Password",doc.getString("Password"));
		if(doc.containsKey("Token"))
			conv.put("Token",doc.getString("Token"));
		}
		catch(JSONException e) {
			System.out.println(e.toString());
		}
		return conv;
	}
	
	public static JSONObject postconv(String s) {
		JSONObject ret = new JSONObject();
		try {
		ret= new JSONObject(s);
		if(checker(ret)) {
			try {
				ret.put("LinkedinID",(String)ret.get("LinkedinID"));
				ret.put("Rollno",(String)ret.get("Rollno"));
				ret.put("Password",(String)ret.get("Password"));
				ret.put("Correct",true);
			}
			catch(Exception e) {
				System.out.println(e.toString());
			}
		}
		else {
			try {
				ret.put("correct",false);
			}
			catch(JSONException g) {
				System.out.println(g.toString());
			}
		}
		}
		catch(JSONException e) {
			System.out.println(e.toString());
			try {
			ret.put("correct",false);
			}
			catch(JSONException f) {
				System.out.println(f.toString());
			}
		}
		return ret;
	}

	public static Boolean checker(JSONObject post) {
		String[] s = {"LinkedinID","Rollno","Password"};
		for(String a:s) {
			if(post.has(a)){
				continue;
			}
			return false;
		} 
		return true;
	}
	
}
