package models;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import org.bson.Document;
public class Jobs {
	
	public static JSONObject getconv(Document doc) {
		JSONObject conv = new JSONObject();
		try {
		if(doc.containsKey("role"))
			conv.put("role",doc.getString("role"));
		if(doc.containsKey("name"))
			conv.put("name",doc.getString("name"));
		if(doc.containsKey("experience"))
			conv.put("experience",doc.get("experience"));
		if(doc.containsKey("salaryl"))
			conv.put("salaryl",doc.get("salaryl"));
		if(doc.containsKey("salaryh"))
			conv.put("salaryh",doc.get("salaryl"));
		if(doc.containsKey("location"))
			conv.put("location",doc.get("location"));
		if(doc.containsKey("responsibilities"))
			conv.put("responsibilities",doc.get("responsibilities"));
		if(doc.containsKey("dateo"))
			conv.put("dateo",doc.get("dateo"));
		if(doc.containsKey("datec"))
			conv.put("datec",doc.get("datec"));
		if(doc.containsKey("jobid"))
			conv.put("jobid",doc.get("jobid"));
		if(doc.containsKey("Token"))
			conv.put("Token",doc.getString("Token"));
		}
		catch(JSONException e) {
			System.out.println(e.toString());
		}
		return conv;
	}
	
	public static JSONObject postconv(String s) {
		JSONObject ret = new JSONObject();
		try {
		ret= new JSONObject(s);
		if(checker(ret)) {
			try {
				ret.put("LinkedinID",(String)ret.get("LinkedinID"));
				ret.put("Rollno",(String)ret.get("Rollno"));
				ret.put("Password",(String)ret.get("Password"));
				ret.put("Correct",true);
			}
			catch(Exception e) {
				System.out.println(e.toString());
			}
		}
		else {
			try {
				ret.put("correct",false);
			}
			catch(JSONException g) {
				System.out.println(g.toString());
			}
		}
		}
		catch(JSONException e) {
			System.out.println(e.toString());
			try {
			ret.put("correct",false);
			}
			catch(JSONException f) {
				System.out.println(f.toString());
			}
		}
		return ret;
	}
	public static Boolean checker(JSONObject post) {
		String[] s = {"role","name","experience"};
		for(String a:s) {
			if(post.has(a)){
				continue;
			}
			return false;
		} 
		return true;
	}
	
}
