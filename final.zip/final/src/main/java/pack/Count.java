package pack;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.bson.Document;
import org.json.JSONObject;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;
 
@WebServlet("/count")
public class Count extends HttpServlet{
	private static final long serialVersionUID = 1L;
	 
    /**
     * @see HttpServlet#HttpServlet()
     */

private static MongoClient getConnection() {
    MongoClient client = MongoClients.create("mongodb+srv://AGLM:cseb@aglm.kqx5g.mongodb.net/Alumini_portal?retryWrites=true&w=majority");
    return client;
}

    public Count() {
        super();
        // TODO Auto-generated constructor stub
     }

/**
 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
 */
protected void doGet(HttpServletRequest request, 
                                   HttpServletResponse response) throws ServletException, IOException {
    boolean user_found = false;
    String db_name = "Alumini_portal",
            db_collection_name = "users";

    // Get the mongodb connection
    MongoDatabase db = getConnection().getDatabase(db_name);

    // Get the mongodb collection.
    MongoCollection<Document> col = db.getCollection(db_collection_name);
    
    try {
    	JSONObject object = new JSONObject();
	    MongoIterable<String> list = db.listCollectionNames();
        for (String name : list) {
           System.out.println(name);
        }
        FindIterable<Document> cursor = col.find();
        Iterator<Document> it = cursor.iterator();
        int i=0;
        while(it.hasNext()) {
            i++;
            user_found = true;
        }
        if(user_found) {
        	HashMap<String,Integer> map = new HashMap<String, Integer>();
        	map.put("Count", i);
        	object = new JSONObject(map);
            PrintWriter out = response.getWriter();
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            out.print(object);
            out.flush();
        }
        else {
            PrintWriter out = response.getWriter();
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.setStatus(400);
            out.flush();
        }
      } catch (Exception e) {
    	  System.out.println(e.toString());
      }
}

/**
 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
 */
protected void doPost(HttpServletRequest request, 
                                   HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub


}
}
