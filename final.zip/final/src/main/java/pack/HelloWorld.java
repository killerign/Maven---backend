package pack;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.bson.Document;
import org.json.JSONException;
import org.json.JSONObject;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;
 
/**
 * Servlet implementation class HelloWorld
 */
@WebServlet("/check")
public class HelloWorld extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
        /**
         * @see HttpServlet#HttpServlet()
         */
	
    private static MongoClient getConnection() {
        MongoClient client = MongoClients.create("mongodb+srv://AGLM:cseb@aglm.kqx5g.mongodb.net/Alumini_portal?retryWrites=true&w=majority");
        return client;
    }
	
        public HelloWorld() {
            super();
            // TODO Auto-generated constructor stub
         }
 
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, 
                                       HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name").trim();
		response.setContentType("text/html"); 
    	        PrintWriter out = response.getWriter(); 
    	        out.print("<h2>Hello "+name+ "</h2>"); 
    	        out.close();
	}
 
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, 
                                       HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder();
	    BufferedReader reader = request.getReader();
	    try {
	        String line;
	        while ((line = reader.readLine()) != null) {
	            sb.append(line).append('\n');
	        }
	    } finally {
	        reader.close();
	    }
        boolean user_found = false;
        String db_name = "Alumini_portal",
                db_collection_name = "users";
 
        // Get the mongodb connection
        MongoDatabase db = getConnection().getDatabase(db_name);
 
        // Get the mongodb collection.
        MongoCollection<Document> col = db.getCollection(db_collection_name);
        
        JSONObject object;
	    try {
	    	object = new JSONObject(sb.toString()); 
	        System.out.println(object.getString("Rollno"));
		    List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		    try {
	        obj.add(new BasicDBObject("Rollno", object.getString("Rollno")));
	        BasicDBObject whereQuery = new BasicDBObject();
	        whereQuery.put("Rollno", object.getString("Rollno"));
	        whereQuery.put("Password",object.getString("Password"));
	        System.out.println("query:"+whereQuery.toString());
	        MongoIterable<String> list = db.listCollectionNames();
	        for (String name : list) {
	           System.out.println(name);
	        }
	        FindIterable<Document> cursor = col.find(whereQuery);
	        String ans;
	        Iterator<Document> it = cursor.iterator();
	        while(it.hasNext()) {
	        	Document temp = it.next();
	            ans = temp.toJson();
	            System.out.println(ans);
	            object = new JSONObject(ans);  
	            user_found = true;
	        }
	        if(user_found) {
	            PrintWriter out = response.getWriter();
	            response.setContentType("application/json");
	            response.setCharacterEncoding("UTF-8");
	            out.print(object);
	            out.flush();
	        }
	        else {
	            PrintWriter out = response.getWriter();
	            response.setContentType("application/json");
	            response.setCharacterEncoding("UTF-8");
	            response.setStatus(212);
	            out.flush();
	        }
		    }
		    catch(JSONException e) {
		    	System.out.println(e.toString());
		    }
	      } catch (Exception e) {
	    	  System.out.println(e.toString());
	      }
	}
 
}