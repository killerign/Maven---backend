package pack;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.bson.Document;
import org.json.JSONException;
import org.json.JSONObject;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
 
@WebServlet("/events")
public class Allevents extends HttpServlet{
	private static final long serialVersionUID = 1L;
	 
    /**
     * @see HttpServlet#HttpServlet()
     */

private static MongoClient getConnection() {
    MongoClient client = MongoClients.create("mongodb+srv://AGLM:cseb@aglm.kqx5g.mongodb.net/Alumini_portal?retryWrites=true&w=majority");
    return client;
}

    public Allevents() {
        super();
        // TODO Auto-generated constructor stub
     }

/**
 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
 */
protected void doGet(HttpServletRequest request, 
                                   HttpServletResponse response) throws ServletException, IOException {
    boolean user_found = false;
    String db_name = "Alumini_portal",
            db_collection_name = "event";
    // Get the mongodb connection
    MongoDatabase db = getConnection().getDatabase(db_name);

    // Get the mongodb collection.
    MongoCollection<Document> col = db.getCollection(db_collection_name);
    
    try {
    	List<String> object = new ArrayList<String>();
	    try {
        String ans;
        BasicDBObject limiter = new BasicDBObject();
        limiter.put("eventid",1);
        FindIterable<Document> cursor = col.find().projection(limiter);
        Iterator<Document> it = cursor.iterator();
        while(it.hasNext()) {
        	Document temp = it.next();
            ans = temp.toJson();
            System.out.println(ans);
            String t = new JSONObject(ans).getString("eventid");
            System.out.println(t);
            object.add(t);
            user_found = true;
        }
        if(user_found) {
            PrintWriter out = response.getWriter();
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            out.print(object);
            out.flush();
        }
        else {
            PrintWriter out = response.getWriter();
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.setStatus(400);
            out.flush();
        }
	    }
	    catch(JSONException e) {
	    	System.out.println(e.toString());
	    }
      } catch (Exception e) {
    	  System.out.println(e.toString());
      }
}

/**
 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
 */
protected void doPost(HttpServletRequest request, 
                                   HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub


}
}
