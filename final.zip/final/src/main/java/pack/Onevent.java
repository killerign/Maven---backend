package pack;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.bson.Document;
import org.json.JSONException;
import org.json.JSONObject;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
 
@WebServlet("/event")
public class Onevent extends HttpServlet{
	private static final long serialVersionUID = 1L;
	 
    /**
     * @see HttpServlet#HttpServlet()
     */

private static MongoClient getConnection() {
    MongoClient client = MongoClients.create("mongodb+srv://AGLM:cseb@aglm.kqx5g.mongodb.net/Alumini_portal?retryWrites=true&w=majority");
    return client;
}

    public Onevent() {
        super();
        // TODO Auto-generated constructor stub
     }

/**
 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
 */
protected void doPost(HttpServletRequest request, 
                                   HttpServletResponse response) throws ServletException, IOException {
	StringBuilder sb = new StringBuilder();
    BufferedReader reader = request.getReader();
    try {
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line).append('\n');
        }
    } finally {
        reader.close();
    }
    boolean user_found = false;
    String db_name = "Alumini_portal",
            db_collection_name = "event";
    // Get the mongodb connection
    MongoDatabase db = getConnection().getDatabase(db_name);

    // Get the mongodb collection.
    MongoCollection<Document> col = db.getCollection(db_collection_name);
    
    try {
    	JSONObject object = new JSONObject();
	    try {
        String ans;
        JSONObject ob = new JSONObject(sb.toString());
        BasicDBObject query = new BasicDBObject();
        query.put("eventid",ob.getString("eventid"));
        FindIterable<Document> cursor = col.find(query).limit(1);
        Iterator<Document> it = cursor.iterator();
        while(it.hasNext()) {
        	Document temp = it.next();
            ans = temp.toJson();
            object = new JSONObject(ans);
            user_found = true;
        }
        if(user_found) {
            PrintWriter out = response.getWriter();
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            out.print(object);
            out.flush();
        }
        else {
            PrintWriter out = response.getWriter();
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.setStatus(400);
            out.flush();
        }
	    }
	    catch(JSONException e) {
	    	System.out.println(e.toString());
	    }
      } catch (Exception e) {
    	  System.out.println(e.toString());
      }
}

/**
 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
 */
protected void doGet(HttpServletRequest request, 
                                   HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub


}
}
